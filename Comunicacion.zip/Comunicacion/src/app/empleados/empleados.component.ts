import { Component } from '@angular/core';
import { Empleado } from '../empleado.model';

@Component({
  selector: 'app-empleados',
  templateUrl: './empleados.component.html',
  styleUrl: './empleados.component.css'
})
export class EmpleadosComponent {
 
  public titulo: string= "Componente EmpleadosComponent" ;
  public empleados: Empleado[]=[
    new Empleado("Antonio", "Recio", "Mayorista", 3000),
    new Empleado("Javier", "Maroto", "Informático", 600),
    new Empleado("Amador", "Rivas", "Vividor", 1800),
    new Empleado("Coque", "Calatrava", "Conserje", 1000),
  ];
}
