import { Component } from '@angular/core';
import { Empleado } from '../empleado.model';
import { EmpleadosComponent } from '../empleados/empleados.component';

@Component({
  selector: 'app-empleado',
  templateUrl: './empleado.component.html',
  styleUrl: './empleado.component.css'
})
export class EmpleadoComponent {
  public titulo="Componente EmpleadoComponent"
  public empleado: Empleado = new Empleado("", "", "", 0);
  
  public inputNombre: string='';
  public inputApellidos: string='';
  public inputCargo: string='';
  public inputSalario: number=0;

  agregarEmpleado () {
    // Si EmpleadosComponent es hijo de EmpleadoComponent -> se pasa información de PADRE a HIJO
    // Si EmpleadosComponent fuera padre de EmpleadoComponent --> se pararía información de HIJO a PADRE
    // Si EmpleadosComponent y EmpleadoComponent no tienen relación entre sí --> se pasa información de uno a otro a través de un servicio.
  }
}
